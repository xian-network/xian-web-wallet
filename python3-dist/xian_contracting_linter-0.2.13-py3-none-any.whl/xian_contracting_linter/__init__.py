from .main import lint_code

__version__ = "0.2.13"
__all__ = ["lint_code"]
