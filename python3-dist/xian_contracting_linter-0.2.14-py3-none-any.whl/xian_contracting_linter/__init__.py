from .main import lint_code

__version__ = "0.2.14"
__all__ = ["lint_code"]
