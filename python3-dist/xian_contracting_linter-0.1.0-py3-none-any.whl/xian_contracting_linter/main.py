import ast
from io import StringIO
import re

from pyflakes.api import check
from pyflakes.reporter import Reporter

from xian_contracting_linter.linter import Linter

__all__ = ["lintCode"]


def lintCode(code):
    """
    Lint the provided smart contract code.

    Args:
        code (str): The smart contract code to lint

    Returns:
        dict: A dictionary containing stdout and stderr output from the linting process
    """
    try:
        # Pyflakes linting
        stdout = StringIO()
        stderr = StringIO()
        reporter = Reporter(stdout, stderr)
        check(code, "<string>", reporter)
        stdout_output = stdout.getvalue()
        stderr_output = stderr.getvalue()

        # Contracting linting
        try:
            linter = Linter()
            tree = ast.parse(code)
            violations = linter.check(tree)
            formatted_new_linter_output = ""
            # Transform new linter output to match pyflakes format
            if violations:
                for violation in violations:
                    line = int(re.search(r"Line (\d+):", violation).group(1))
                    message = re.search(r"Line \d+: (.+)", violation).group(1)
                    formatted_violation_output = f"<string>:{line}:0: {message}\n"
                    formatted_new_linter_output += formatted_violation_output
        except Exception as e:
            formatted_new_linter_output = (
                f"Error during contracting linting: {str(e)}\n"
            )

        # Combine stderr output
        combined_stderr_output = f"{stderr_output}{formatted_new_linter_output}"

        return {"stdout": stdout_output, "stderr": combined_stderr_output}
    except Exception as e:
        return {"stdout": "", "stderr": f"General linting error: {str(e)}"}
